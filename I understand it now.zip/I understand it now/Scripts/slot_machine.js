const spinButton = document.getElementById("spin");
const resultDiv = document.getElementById("result");
const reel1 = document.getElementById("reel1");
const reel2 = document.getElementById("reel2");
const reel3 = document.getElementById("reel3");

let isSpinning = false;

const randomSlotValue = () => Math.floor(Math.random() * 7) + 1;

const spinReel = (reel) => {
  return new Promise((resolve) => {
    const spinDuration = Math.random() * 1000 + 1000;
    const interval = 100;
    let currentValue = randomSlotValue();

    const intervalId = setInterval(() => {
      currentValue = randomSlotValue();
      reel.textContent = currentValue;
    }, interval);

    setTimeout(() => {
      clearInterval(intervalId);
      const finalValue = randomSlotValue();
      reel.textContent = finalValue;
      resolve(finalValue);
    }, spinDuration);
  });
};

spinButton.addEventListener("click", async () => {
  if (isSpinning) return;
  isSpinning = true;

  resultDiv.textContent = "Spinning...";
  const [val1, val2, val3] = await Promise.all([
    spinReel(reel1),
    spinReel(reel2),
    spinReel(reel3),
  ]);

  isSpinning = false;


  if (val1 === val2 && val2 === val3) {
    resultDiv.textContent = `GGs (Jackpot)${val1}`;
  } else if (val1 === val2 || val2 === val3 || val1 === val3) {
    resultDiv.textContent = `skibidi (2 match small win)${val1}, ${val2}, ${val3}`;
  } else {
    resultDiv.textContent = `I hate not gambling away all my life saving what bout you (you lost bucko, L luck)${val1}, ${val2}, ${val3}`;
  }

  const outcome = { val1, val2, val3, result: resultDiv.textContent };
  localStorage.setItem("slotMachineOutcome", JSON.stringify(outcome));
});
