const suits = ["H", "D", "C", "S"]; 
const ranks = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];
let deck, playerHand, dealerHand, playerScore, dealerScore;

const dealerCardsDiv = document.getElementById("dealer-cards");
const playerCardsDiv = document.getElementById("player-cards");
const dealerScoreText = document.getElementById("dealer-score");
const playerScoreText = document.getElementById("player-score");
const resultText = document.getElementById("result");
const hitButton = document.getElementById("hit");
const standButton = document.getElementById("stand");
const newGameButton = document.getElementById("new-game");

function createDeck() {
  return suits.flatMap(suit => ranks.map(rank => `${rank}${suit}`));
}

function shuffleDeck(deck) {
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }
  return deck;
}

function dealCard(hand) {
  const card = deck.pop();
  hand.push(card);
  return card;
}

function calculateScore(hand) {
  let score = 0;
  let aces = 0;

  hand.forEach(card => {
    const value = card.slice(0, -1); 
    if (value === "A") {
      score += 11;
      aces++;
    } else if (["K", "Q", "J"].includes(value)) {
      score += 10;
    } else {
      score += parseInt(value, 10);
    }
  });
  while (score > 21 && aces > 0) {
    score -= 10;
    aces--;
  }

  return score;
}

function updateUI() {
  dealerCardsDiv.innerHTML = dealerHand.map(card => `<div class="card">${card}</div>`).join("");
  playerCardsDiv.innerHTML = playerHand.map(card => `<div class="card">${card}</div>`).join("");

  dealerScoreText.textContent = `Score: ${calculateScore(dealerHand)}`;
  playerScoreText.textContent = `Score: ${calculateScore(playerHand)}`;
}

function checkGameOver() {
  playerScore = calculateScore(playerHand);
  dealerScore = calculateScore(dealerHand);

  if (playerScore > 21) {
    resultText.textContent = "You busted! Dealer wins.";
    endGame();
  } else if (dealerScore > 21) {
    resultText.textContent = "Dealer busted! You win.";
    endGame();
  } else if (dealerScore >= 17) {
    if (playerScore > dealerScore) {
      resultText.textContent = "You win!";
    } else if (playerScore < dealerScore) {
      resultText.textContent = "Dealer wins!";
    } else {
      resultText.textContent = "It's a tie!";
    }
    endGame();
  }
}

function endGame() {
  hitButton.disabled = true;
  standButton.disabled = true;
}

function newGame() {
  deck = shuffleDeck(createDeck());
  playerHand = [];
  dealerHand = [];
  resultText.textContent = "";
  hitButton.disabled = false;
  standButton.disabled = false;

  dealCard(playerHand);
  dealCard(playerHand);
  dealCard(dealerHand);
  dealCard(dealerHand);

  updateUI();
}

hitButton.addEventListener("click", () => {
  dealCard(playerHand);
  updateUI();
  checkGameOver();
});

standButton.addEventListener("click", () => {
  while (calculateScore(dealerHand) < 17) {
    dealCard(dealerHand);
  }
  updateUI();
  checkGameOver();
});

newGameButton.addEventListener("click", newGame);

newGame();
